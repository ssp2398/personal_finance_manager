// src/components/MoneyGuruchat.js

import React, { useState } from 'react';
import '../../components/MoneyGuruchat/MoneyGuruChat.css'

const predefinedQA = [
  {
    question: "How can I save more money?",
    answer: "Start by tracking your expenses, setting a monthly budget, and cutting non-essential spending."
  },
  {
    question: "How can i save my 40% of income every Month",
    answer: "By dividing expences in 10% on fuel , 20% on Grocery and 30% on other expences ,you can save 40% of your income."
  },
  {
    question: "How much should I save monthly?",
    answer: "A common rule is to save at least 20% of your income each month."
  },
  {
    question: "How can i set my monthly budget?",
    answer: "Initially you can set your monthly budget by 50% of your total income and focusing on more saving for future emergency"
  },
  {
    question: "How to reduce debt?",
    answer: "List all debts, prioritize high-interest ones, and pay more than the minimum whenever possible."
  }
];

function MoneyGuruChat() {
  const [isOpen, setIsOpen] = useState(false);
  const [chat, setChat] = useState([]);

  const handleQuestionClick = (qa) => {
    setChat(prev => [...prev, { type: 'question', text: qa.question }, { type: 'answer', text: qa.answer }]);
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="moneyguru-chat-container">
      {isOpen && (
        <div className="moneyguru-chat-box">
          <div className="moneyguru-header">
            <h4>💬 MoneyGuru Assistant</h4>
            <button className="close-btn" onClick={toggleChat}>×</button>
          </div>

          <div className="moneyguru-content">
            {chat.length === 0 && (
              <div className="moneyguru-questions">
                <p><strong>Select a question:</strong></p>
                {predefinedQA.map((qa, index) => (
                  <button key={index} className="moneyguru-question-btn" onClick={() => handleQuestionClick(qa)}>
                    {qa.question}
                  </button>
                ))}
              </div>
            )}

            {chat.length > 0 && (
              <div className="moneyguru-chat-view">
                {chat.map((msg, index) => (
                  <div key={index} className={`moneyguru-msg ${msg.type}`}>
                    {msg.text}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      <button className="moneyguru-toggle-btn" onClick={toggleChat}>
        {isOpen ? 'Close Chat' : '💬 Ask MoneyGuru'}
      </button>
    </div>
  );
}

export default MoneyGuruChat;
