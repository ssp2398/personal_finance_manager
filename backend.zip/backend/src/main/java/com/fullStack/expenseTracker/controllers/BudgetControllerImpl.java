package com.fullStack.expenseTracker.controllers;

public class BudgetControllerImpl extends BudgetController {
}
