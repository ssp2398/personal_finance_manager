package com.fullStack.expenseTracker.exceptions;

public class CategoryServiceLogicException extends Exception{
    public CategoryServiceLogicException(String message) {
        super(message);
    }
}
