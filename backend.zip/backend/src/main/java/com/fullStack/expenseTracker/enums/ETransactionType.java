package com.fullStack.expenseTracker.enums;

public enum ETransactionType {
    TYPE_EXPENSE,
    TYPE_INCOME
}
