package com.fullStack.expenseTracker.exceptions;

public class TransactionServiceLogicException extends Exception{
    public TransactionServiceLogicException(String message) {
        super(message);
    }
}
