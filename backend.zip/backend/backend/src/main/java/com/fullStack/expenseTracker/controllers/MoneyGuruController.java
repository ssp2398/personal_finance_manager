package com.fullStack.expenseTracker.controllers;

import com.fullStack.expenseTracker.services.OpenAIApiService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/moneyguru")
@CrossOrigin(origins = "*") // dev only; lock this down in production
public class MoneyGuruController {

    private static final Logger log = LoggerFactory.getLogger(MoneyGuruController.class);
    private final OpenAIApiService openAIApiService;

    public MoneyGuruController(OpenAIApiService openAIApiService) {
        this.openAIApiService = openAIApiService;
    }

    @PostMapping("/ask")
    public ResponseEntity<?> askMoneyGuru(@RequestBody Map<String, String> request) {
        String question = request.get("question");
        if (question == null || question.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "question is required"));
        }

        try {
            String aiResponse = openAIApiService.getResponse(question);
            return ResponseEntity.ok(Map.of("reply", aiResponse));
        } catch (Exception e) {
            log.error("AI service failed for question: {}", question, e);
            return ResponseEntity.status(500).body(Map.of("error", "AI service failed", "detail", e.getMessage()));
        }
    }
}
