package com.fullStack.expenseTracker.enums;

public enum ETransactionFrequency {
    ONE_TIME,
    DAILY,
    MONTHLY
}
