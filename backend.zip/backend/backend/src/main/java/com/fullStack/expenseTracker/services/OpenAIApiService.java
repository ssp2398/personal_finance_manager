package com.fullStack.expenseTracker.services;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;


@Service
public class OpenAIApiService {

    private static final Logger log = LoggerFactory.getLogger(OpenAIApiService.class);
    private static final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();

    @Value("${openai.api.key:}")
    private String openaiApiKey;


    public String getResponse(String userMessage) {
        try {
            String apiKey = resolveApiKey();
            String payload = mapper.createObjectNode()
                    .put("model", "gpt-3.5-turbo")
                    .put("temperature", 0.6)
                    .put("max_tokens", 400)
                    .set("messages", mapper.createArrayNode()
                            .add(mapper.createObjectNode()
                                    .put("role", "system")
                                    .put("content", "You are MoneyGuru, an assistant that gives short, practical personal finance advice for budgeting, saving, and expense tracking. Keep answers concise and actionable."))
                            .add(mapper.createObjectNode()
                                    .put("role", "user")
                                    .put("content", userMessage)))
                    .toString();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.openai.com/v1/chat/completions"))
                    .timeout(Duration.ofSeconds(30))
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + apiKey)
                    .POST(HttpRequest.BodyPublishers.ofString(payload))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            int status = response.statusCode();
            String body = response.body();

            if (status >= 300) {
                log.error("OpenAI API returned non-2xx status: {} body: {}", status, body);
                throw new RuntimeException("OpenAI API error: " + status);
            }

            JsonNode root = mapper.readTree(body);
            JsonNode choice = root.path("choices").isArray() && root.path("choices").size() > 0
                    ? root.path("choices").get(0) : null;

            String assistantText = "";
            if (choice != null) {
                assistantText = choice.path("message").path("content").asText("");
            }

            if (assistantText == null || assistantText.isBlank()) {
                log.warn("OpenAI returned empty assistant reply, full body: {}", body);
                return "Sorry — I couldn't generate a response right now.";
            }

            return assistantText.trim();
        } catch (Exception e) {
            log.error("Error while calling OpenAI API", e);
            throw new RuntimeException("AI service failed: " + e.getMessage(), e);
        }
    }

    private String resolveApiKey() {
        // Priority: property injected (openai.api.key) -> environment var OPENAI_API_KEY -> fail
        if (openaiApiKey != null && !openaiApiKey.isBlank()) {
            return openaiApiKey;
        }
        String fromEnv = System.getenv("OPENAI_API_KEY");
        if (fromEnv != null && !fromEnv.isBlank()) {
            return fromEnv;
        }
        throw new IllegalStateException("OpenAI API key not configured. Set OPENAI_API_KEY env var or openai.api.key property.");
    }
}
